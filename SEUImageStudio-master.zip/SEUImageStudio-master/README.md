SEUImageStudio
==============

a image process java gui program from Southeast University, China. Let students learn digital picture processing  efficiently!