#!/bin/bash
javac -d . Complex.java
javac -d . process.java
javac -d . ImagePanel.java
javac -d . ImageStudio.java
