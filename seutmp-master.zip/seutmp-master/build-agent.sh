cd build
cmake ..
make
make install
