/***************************************************************************
 *                              SEU RoboCup Simulation Team
 *                     -------------------------------------------------
 * Copyright (c) Southeast University , Nanjing, China.
 * All rights reserved.
 *
 * $Id: Logger.hpp,v 1.2 2007/03/13 07:34:10 xy Exp $
 *
 ****************************************************************************/


#define DISABLE_ALL_LOG

//#ifdef DISABLE_ALL_LOG
#include "NoLogger.h"
//#else

