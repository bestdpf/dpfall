/***************************************************************************
 *                              SEU RoboCup Simulation Team
 *                     -------------------------------------------------
 * Copyright (c) Southeast University , Nanjing, China.
 * All rights reserved.
 *
 * $Id:AccelerometerSensor.h,v 1.0 2010/03/15  Allen Exp $
 *
 ****************************************************************************/
#include "AccelerometerSensor.h"

namespace robot {
    namespace device {
        namespace sensor {

            AccelerometerSensor::AccelerometerSensor()
            {
            }

        } /* namespace sensor */
    } /* namespace device */
} /* namespace robot */
