/***************************************************************************
 *                              SEU RoboCup Simulation Team
 *                     -------------------------------------------------
 * Copyright (c) Southeast University , Nanjing, China.
 * All rights reserved.
 *
 * $Id$
 *
 ****************************************************************************/
#include "GyroRateSensor.h"

namespace robot {
    namespace device {
        namespace sensor {

            GyroRateSensor::GyroRateSensor()
            {
            }
            
        } /* namespace sensor */
    } /* namespace device */
} /* namespace robot */
