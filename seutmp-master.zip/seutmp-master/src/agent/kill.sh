#!/bin/bash
#
# IranOpen 2011 sample kill script for 3D soccer simulation
#
killall -9 "seu-spark-agent" &> /dev/null

 
